import React from 'react';
import Main from './Main';

function App() {
  return (
    <div>
      <Main 
        question='This is the first question'
        type='checkbox'
      />
      <br></br>
      <Main 
        question='This is the second question'
        type='checkbox'
      />
    </div>
  );
}

export default App;
