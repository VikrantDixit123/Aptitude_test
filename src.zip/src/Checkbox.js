import React from 'react'


export default class Options extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            checked: 'false'
        }
    }

    handleCheck = () => {
        if (this.state.checked === 'false')
            this.setState({ checked: 'true' });
        else {

            this.setState({ checked: 'false' });
        }
    }

    render() {
        return (
            <div>
                {<input type="checkbox" onChange={this.handleCheck} />}
                <label>{this.props.label}</label>
            </div>
        )
    }
}