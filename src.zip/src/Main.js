import React from 'react'
import Questions from './Questions';
import Options from './Options';


export default function Main(props) {    
    return (
      <div>
        <Questions ques= {props.question}/>
        <Options opt={props.type}/>
      </div>
    );
  }
  