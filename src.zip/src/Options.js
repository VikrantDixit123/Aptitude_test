import React from 'react'
import Checkbox from './Checkbox';

export default class Options extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            checked: 'false'
        }
    }


    render() {
        if (this.props.opt === 'checkbox') {                                //currently for Checkbox
        return (
            
            <div>
                <Checkbox
                    label='First'
                />
                <Checkbox
                    label='Second'
                />
                <Checkbox
                    label='Third'
                />
                <Checkbox
                    label='Fourth'
                />
            </div>
         );    
    }
       
    }
}

