import React from 'react'


export default class Questions extends React.Component {
    render() {
        return (
            <div>
                {this.props.ques}
            </div>
        );
    }
}
